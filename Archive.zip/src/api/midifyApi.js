// import axios from 'axios';

// const API_BASE_URL = 'http://127.0.0.1:8000/api';

// const token = '07d6787ec303767bdb118a0b6a0ac5802ee75537';

// // Axios instance with default settings
// const apiClient = axios.create({
//   baseURL: API_BASE_URL,
//   headers: {
//     'Authorization': `Token ${token}`,
//     'Content-Type': 'application/json',
//   },
  
// });

// // Attach token to requests automatically
// apiClient.interceptors.request.use((config) => {
//   // const token = localStorage.getItem('authToken'); 
//   if (token) {
//     config.headers.Authorization = `Token ${token}`;
//   }
//   return config;
// });

// // Centralized error handling
// const handleApiError = (error) => {
//   console.error("API Error:", error.response?.data || error.message);
//   throw error.response?.data || error.message;
// };

// // API functions
// export const getApiOverview = async () => {
//   try {
//     const response = await apiClient.get('/');
//     return response.data;
//   } catch (error) {
//     handleApiError(error);
//   }
// };

// // API Function: Upload a File
// export const uploadFile = async (file) => {
//   console.log("This means we get to the secret function ");
//   const formData = new FormData();
//   formData.append('file', file); // Ensure the key matches the backend expectation
//   console.log(file instanceof File); // Should return `true`



//   try {
//     const response = await apiClient.post('/upload/', formData, {
//       headers: { 'Content-Type': 'multipart/form-data' },
//     });
//     // const response = await apiClient.post('/upload/', formData);
   
//     console.log('Backend Response:', response.data);
//     return response.data; // Return the full response from the backend
//   } catch (error) {
//     console.error('Error uploading file:', error);
//     throw error;
//   }
// };

// export const deleteUpload = async (id) => {
//   try {
//     await apiClient.delete(`/upload/${id}/`);
//     console.log('File deleted successfully.');
//   } catch (error) {
//     console.error('Error deleting file:', error);
//     throw error;
//   }
// };


// export const fetchUploadHistory = async () => {
//   try {
//     const response = await apiClient.get('/history/');
//     return response.data;
//   } catch (error) {
//     handleApiError(error);
//   }
// };

// export const fetchProfile = async () => {
//   try {
//     const response = await apiClient.get('/profile/');
//     return response.data;
//   } catch (error) {
//     handleApiError(error);
//   }
// };

// export const updateProfile = async (data) => {
//   try {
//     const response = await apiClient.put('/profile/', data);
//     return response.data;
//   } catch (error) {
//     handleApiError(error);
//   }
// };
