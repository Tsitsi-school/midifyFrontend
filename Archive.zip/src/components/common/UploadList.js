import React from 'react';
import styled from 'styled-components';
import InsertDriveFileOutlinedIcon from '@mui/icons-material/InsertDriveFileOutlined';
import { deleteUpload } from '../../api/midifyApi';


const FileContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 15px 20px;
  border: 0.5px solid var(--file-container-border-color);
  border-radius: 1px;
  margin-top: 10px;
  background-color: var(--file-container-background-color);
`;

const FileInfo = styled.div`
  display: flex;
  align-items: center;
`;

const FileIcon = styled(InsertDriveFileOutlinedIcon)`
  font-size: 2rem !important;
  margin-right: 8px; /* Adjust this to control spacing between icon and text */
  color: var(--file-info-color);
`;

const FileName = styled.span`
  font-size: 1rem;
  color: var(--file-info-color);
`;

const FileSize = styled.span`
  font-size: 0.9rem;
  color: var(--file-info-color);
`;

const DeleteButton = styled.button`
  padding: 5px 10px;
  background-color: red;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 0.8rem;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: darkred;
  }
`;

const UploadList = ({ files, setUploadedFiles }) => {

  // const handleDelete = async (id) => {
  //   try {
  //     await deleteUpload(id); // Call API to delete the file
  //     setUploadedFiles((prevFiles) => prevFiles.filter((file) => file.id !== id)); // Update parent state
  //   } catch (error) {
  //     console.error('Error deleting file:', error);
  //   }
  // };

  return files.map((file) => (
    <FileContainer key={file.name}>
      <FileInfo>
        <FileIcon />
        <FileName>{file.name}</FileName>
      </FileInfo>
      <FileSize>{(file.size / 1024).toFixed(2)} KB</FileSize>
      {/* <DeleteButton onClick={() => handleDelete(file.id)}>Delete</DeleteButton> */}

    </FileContainer>
  ));
};

export default UploadList;
